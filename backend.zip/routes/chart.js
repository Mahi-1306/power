const express = require("express");
const { PrismaClient } = require("@prisma/client");
const verifyToken = require("../middleware/verifyToken");
const router = express.Router();
const prisma = new PrismaClient();

router.use(verifyToken);

router.get("/data", async (req, res) => {
  try {
    let { startDate, endDate, groupBy } = req.query;
    const userId = req.user.userId;

    // Default to today if not provided
    if (!startDate || !endDate) {
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, "0");
      const dd = String(today.getDate()).padStart(2, "0");
      startDate = `${yyyy}-${mm}-${dd}T00:00:00.000Z`;
      endDate = `${yyyy}-${mm}-${dd}T23:59:59.999Z`;
    }

    groupBy = groupBy ? groupBy.toLowerCase() : "day";

    let data = [];

    if (groupBy === "month") {
      data = await prisma.$queryRaw`
        SELECT DATE_FORMAT(machinedata.date, '%Y-%m') AS period,
               SUM(CAST(machinedata.data AS DECIMAL(10,2))) AS total
        FROM machinedata
        JOIN machine ON machinedata.machine_id = machine.id
        WHERE machinedata.date BETWEEN ${new Date(startDate)} AND ${new Date(endDate)}
          AND machine.created_by = ${userId}
        GROUP BY period
        ORDER BY period;
      `;
    } else if (groupBy === "year") {
      data = await prisma.$queryRaw`
        SELECT DATE_FORMAT(machinedata.date, '%Y') AS period,
               SUM(CAST(machinedata.data AS DECIMAL(10,2))) AS total
        FROM machinedata
        JOIN machine ON machinedata.machine_id = machine.id
        WHERE machinedata.date BETWEEN ${new Date(startDate)} AND ${new Date(endDate)}
          AND machine.created_by = ${userId}
        GROUP BY period
        ORDER BY period;
      `;
    } else {
      // Default to daily
      data = await prisma.$queryRaw`
        SELECT DATE(machinedata.date) AS period,
               SUM(CAST(machinedata.data AS DECIMAL(10,2))) AS total
        FROM machinedata
        JOIN machine ON machinedata.machine_id = machine.id
        WHERE machinedata.date BETWEEN ${new Date(startDate)} AND ${new Date(endDate)}
          AND machine.created_by = ${userId}
        GROUP BY period
        ORDER BY period;
      `;
    }

    res.json({
      startDate,
      endDate,
      data,
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
