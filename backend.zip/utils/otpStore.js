// utils/otpStore.js
const verifiedOTPs = new Map();

module.exports = { verifiedOTPs };
